# called when the map sends you back to spawn / restarts your run
scoreboard players reset @s pk_level
