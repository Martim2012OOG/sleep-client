# /function break:true -> players can break/place blocks again (switch to creative/survival yourself)
scoreboard players set #break pk_flag 1
tellraw @a [{text:"[Map] ",color:"gold"},{text:"Breaking is now ",color:"white"},{text:"ON",color:"green",bold:true},{text:" - use /gamemode creative to build.",color:"gray"}]
