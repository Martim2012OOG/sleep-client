# Kubo client: the level is drawn by the client (LEVEL X / 100), so no boss bar is shown here.
# Hide the bar this player may still have from an older version of the pack.
$bossbar set pk:lvl_$(old) players
$bossbar set pk:lvl_$(old) visible false
$bossbar set pk:lvl_$(new) visible false
