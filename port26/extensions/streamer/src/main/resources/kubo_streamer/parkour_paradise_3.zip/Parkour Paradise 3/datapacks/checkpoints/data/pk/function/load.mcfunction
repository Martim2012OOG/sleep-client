scoreboard objectives add pk_level dummy "Checkpoint"
scoreboard objectives add pk_rejoin dummy
scoreboard objectives add pk_left minecraft.custom:minecraft.leave_game
scoreboard objectives add pk_click minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add pk_flag dummy
execute unless score #break pk_flag matches 0..1 run scoreboard players set #break pk_flag 0
scoreboard objectives add pk_shown dummy
function pk:bars_create
