scoreboard players reset @s pk_click
execute unless score @s pk_level matches 1.. run return run title @s actionbar {text:"No checkpoint yet - step on a gold plate first",color:"gold"}
function pk:to_checkpoint
title @s actionbar [{text:"Back to level ",color:"gold"},{score:{name:"@s",objective:"pk_level"},color:"yellow",bold:true}]
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1.3
