# wait a bit so the map's own join logic runs first, then put the player back on their checkpoint
scoreboard players remove @s pk_rejoin 1
execute unless score @s pk_rejoin matches 0 run return 0
scoreboard players reset @s pk_rejoin
execute unless score @s pk_level matches 1.. run return 0
function pk:to_checkpoint
title @s actionbar [{text:"Welcome back! Level ",color:"gold"},{score:{name:"@s",objective:"pk_level"},color:"yellow",bold:true}]
