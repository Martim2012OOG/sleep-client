# /function break:false -> nobody can break the map (everyone is kept in adventure mode)
scoreboard players set #break pk_flag 0
gamemode adventure @a[gamemode=!adventure,gamemode=!spectator,tag=!flight]
tellraw @a [{text:"[Map] ",color:"gold"},{text:"Breaking is now ",color:"white"},{text:"OFF",color:"red",bold:true},{text:" - the map is protected.",color:"gray"}]
