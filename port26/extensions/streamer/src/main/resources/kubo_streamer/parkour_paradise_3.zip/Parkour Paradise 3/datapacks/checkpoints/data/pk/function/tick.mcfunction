# back-to-checkpoint item always in the last hotbar slot (not while in training mode, it uses that slot)
execute as @a[tag=!training_mode] unless items entity @s hotbar.8 carrot_on_a_stick[custom_data~{pk_back:1b}] run function pk:give_back
execute as @a[tag=training_mode] run clear @s carrot_on_a_stick[custom_data~{pk_back:1b}]
execute as @e[type=item] if items entity @s contents *[custom_data~{pk_back:1b}] run kill @s
# right click the item
execute as @a[scores={pk_click=1..}] at @s run function pk:back
# rejoin -> back to your checkpoint
execute as @a[scores={pk_left=1..}] run function pk:rejoin_start
execute as @a[scores={pk_rejoin=1..}] run function pk:rejoin_tick
# standing on a gold checkpoint plate
execute as @a[gamemode=!spectator] at @s if block ~ ~ ~ minecraft:light_weighted_pressure_plate run function pk:plate_check
# map protection: while breaking is OFF keep everyone in adventure (training-mode flight excluded)
execute if score #break pk_flag matches 0 run gamemode adventure @a[gamemode=!adventure,gamemode=!spectator,tag=!flight]
# new players start at level 0
execute as @a unless score @s pk_level matches 0.. run scoreboard players set @s pk_level 0
# reaching level 100 (shares its checkpoint with 99)
execute as @a[scores={level=100}] unless score @s pk_level matches 100.. run function pk:reach {l:100}
# LEVEL X / 100 bar at the top of the screen
execute as @a unless score @s pk_shown = @s pk_level run function pk:bar_update
