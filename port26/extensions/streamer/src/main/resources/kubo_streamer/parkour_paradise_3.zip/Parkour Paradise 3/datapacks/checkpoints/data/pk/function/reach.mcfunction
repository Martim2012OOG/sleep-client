$execute if score @s pk_level matches $(l).. run return 0
$scoreboard players set @s pk_level $(l)
execute if score @s pk_level matches 100.. run return run function pk:finished
# Kubo client: the "CHECKPOINT!" sweep is drawn by the client, so no title here
playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.2
