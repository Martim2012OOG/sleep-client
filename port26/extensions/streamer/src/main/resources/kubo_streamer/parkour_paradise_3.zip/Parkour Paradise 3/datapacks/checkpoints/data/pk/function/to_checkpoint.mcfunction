# leave the spawn lobby state of the map so it doesn't pull you back to spawn
tag @s remove spawn
attribute @s minecraft:safe_fall_distance modifier remove spawn
tag @s add ingame
scoreboard players operation @s level = @s pk_level
function pk:tp_level
