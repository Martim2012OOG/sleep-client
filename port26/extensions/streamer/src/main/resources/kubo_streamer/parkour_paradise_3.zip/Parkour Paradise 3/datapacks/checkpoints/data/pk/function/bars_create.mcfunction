bossbar add pk:lvl_0 [{text:"LEVEL ",color:"white",bold:true},{text:"0 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_0 max 100
bossbar set pk:lvl_0 value 0
bossbar set pk:lvl_0 color blue
bossbar set pk:lvl_0 style notched_10
bossbar add pk:lvl_1 [{text:"LEVEL ",color:"white",bold:true},{text:"1 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_1 max 100
bossbar set pk:lvl_1 value 1
bossbar set pk:lvl_1 color blue
bossbar set pk:lvl_1 style notched_10
bossbar add pk:lvl_2 [{text:"LEVEL ",color:"white",bold:true},{text:"2 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_2 max 100
bossbar set pk:lvl_2 value 2
bossbar set pk:lvl_2 color blue
bossbar set pk:lvl_2 style notched_10
bossbar add pk:lvl_3 [{text:"LEVEL ",color:"white",bold:true},{text:"3 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_3 max 100
bossbar set pk:lvl_3 value 3
bossbar set pk:lvl_3 color blue
bossbar set pk:lvl_3 style notched_10
bossbar add pk:lvl_4 [{text:"LEVEL ",color:"white",bold:true},{text:"4 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_4 max 100
bossbar set pk:lvl_4 value 4
bossbar set pk:lvl_4 color blue
bossbar set pk:lvl_4 style notched_10
bossbar add pk:lvl_5 [{text:"LEVEL ",color:"white",bold:true},{text:"5 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_5 max 100
bossbar set pk:lvl_5 value 5
bossbar set pk:lvl_5 color blue
bossbar set pk:lvl_5 style notched_10
bossbar add pk:lvl_6 [{text:"LEVEL ",color:"white",bold:true},{text:"6 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_6 max 100
bossbar set pk:lvl_6 value 6
bossbar set pk:lvl_6 color blue
bossbar set pk:lvl_6 style notched_10
bossbar add pk:lvl_7 [{text:"LEVEL ",color:"white",bold:true},{text:"7 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_7 max 100
bossbar set pk:lvl_7 value 7
bossbar set pk:lvl_7 color blue
bossbar set pk:lvl_7 style notched_10
bossbar add pk:lvl_8 [{text:"LEVEL ",color:"white",bold:true},{text:"8 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_8 max 100
bossbar set pk:lvl_8 value 8
bossbar set pk:lvl_8 color blue
bossbar set pk:lvl_8 style notched_10
bossbar add pk:lvl_9 [{text:"LEVEL ",color:"white",bold:true},{text:"9 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_9 max 100
bossbar set pk:lvl_9 value 9
bossbar set pk:lvl_9 color blue
bossbar set pk:lvl_9 style notched_10
bossbar add pk:lvl_10 [{text:"LEVEL ",color:"white",bold:true},{text:"10 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_10 max 100
bossbar set pk:lvl_10 value 10
bossbar set pk:lvl_10 color blue
bossbar set pk:lvl_10 style notched_10
bossbar add pk:lvl_11 [{text:"LEVEL ",color:"white",bold:true},{text:"11 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_11 max 100
bossbar set pk:lvl_11 value 11
bossbar set pk:lvl_11 color blue
bossbar set pk:lvl_11 style notched_10
bossbar add pk:lvl_12 [{text:"LEVEL ",color:"white",bold:true},{text:"12 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_12 max 100
bossbar set pk:lvl_12 value 12
bossbar set pk:lvl_12 color blue
bossbar set pk:lvl_12 style notched_10
bossbar add pk:lvl_13 [{text:"LEVEL ",color:"white",bold:true},{text:"13 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_13 max 100
bossbar set pk:lvl_13 value 13
bossbar set pk:lvl_13 color blue
bossbar set pk:lvl_13 style notched_10
bossbar add pk:lvl_14 [{text:"LEVEL ",color:"white",bold:true},{text:"14 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_14 max 100
bossbar set pk:lvl_14 value 14
bossbar set pk:lvl_14 color blue
bossbar set pk:lvl_14 style notched_10
bossbar add pk:lvl_15 [{text:"LEVEL ",color:"white",bold:true},{text:"15 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_15 max 100
bossbar set pk:lvl_15 value 15
bossbar set pk:lvl_15 color blue
bossbar set pk:lvl_15 style notched_10
bossbar add pk:lvl_16 [{text:"LEVEL ",color:"white",bold:true},{text:"16 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_16 max 100
bossbar set pk:lvl_16 value 16
bossbar set pk:lvl_16 color blue
bossbar set pk:lvl_16 style notched_10
bossbar add pk:lvl_17 [{text:"LEVEL ",color:"white",bold:true},{text:"17 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_17 max 100
bossbar set pk:lvl_17 value 17
bossbar set pk:lvl_17 color blue
bossbar set pk:lvl_17 style notched_10
bossbar add pk:lvl_18 [{text:"LEVEL ",color:"white",bold:true},{text:"18 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_18 max 100
bossbar set pk:lvl_18 value 18
bossbar set pk:lvl_18 color blue
bossbar set pk:lvl_18 style notched_10
bossbar add pk:lvl_19 [{text:"LEVEL ",color:"white",bold:true},{text:"19 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_19 max 100
bossbar set pk:lvl_19 value 19
bossbar set pk:lvl_19 color blue
bossbar set pk:lvl_19 style notched_10
bossbar add pk:lvl_20 [{text:"LEVEL ",color:"white",bold:true},{text:"20 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_20 max 100
bossbar set pk:lvl_20 value 20
bossbar set pk:lvl_20 color blue
bossbar set pk:lvl_20 style notched_10
bossbar add pk:lvl_21 [{text:"LEVEL ",color:"white",bold:true},{text:"21 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_21 max 100
bossbar set pk:lvl_21 value 21
bossbar set pk:lvl_21 color blue
bossbar set pk:lvl_21 style notched_10
bossbar add pk:lvl_22 [{text:"LEVEL ",color:"white",bold:true},{text:"22 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_22 max 100
bossbar set pk:lvl_22 value 22
bossbar set pk:lvl_22 color blue
bossbar set pk:lvl_22 style notched_10
bossbar add pk:lvl_23 [{text:"LEVEL ",color:"white",bold:true},{text:"23 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_23 max 100
bossbar set pk:lvl_23 value 23
bossbar set pk:lvl_23 color blue
bossbar set pk:lvl_23 style notched_10
bossbar add pk:lvl_24 [{text:"LEVEL ",color:"white",bold:true},{text:"24 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_24 max 100
bossbar set pk:lvl_24 value 24
bossbar set pk:lvl_24 color blue
bossbar set pk:lvl_24 style notched_10
bossbar add pk:lvl_25 [{text:"LEVEL ",color:"white",bold:true},{text:"25 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_25 max 100
bossbar set pk:lvl_25 value 25
bossbar set pk:lvl_25 color blue
bossbar set pk:lvl_25 style notched_10
bossbar add pk:lvl_26 [{text:"LEVEL ",color:"white",bold:true},{text:"26 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_26 max 100
bossbar set pk:lvl_26 value 26
bossbar set pk:lvl_26 color blue
bossbar set pk:lvl_26 style notched_10
bossbar add pk:lvl_27 [{text:"LEVEL ",color:"white",bold:true},{text:"27 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_27 max 100
bossbar set pk:lvl_27 value 27
bossbar set pk:lvl_27 color blue
bossbar set pk:lvl_27 style notched_10
bossbar add pk:lvl_28 [{text:"LEVEL ",color:"white",bold:true},{text:"28 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_28 max 100
bossbar set pk:lvl_28 value 28
bossbar set pk:lvl_28 color blue
bossbar set pk:lvl_28 style notched_10
bossbar add pk:lvl_29 [{text:"LEVEL ",color:"white",bold:true},{text:"29 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_29 max 100
bossbar set pk:lvl_29 value 29
bossbar set pk:lvl_29 color blue
bossbar set pk:lvl_29 style notched_10
bossbar add pk:lvl_30 [{text:"LEVEL ",color:"white",bold:true},{text:"30 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_30 max 100
bossbar set pk:lvl_30 value 30
bossbar set pk:lvl_30 color blue
bossbar set pk:lvl_30 style notched_10
bossbar add pk:lvl_31 [{text:"LEVEL ",color:"white",bold:true},{text:"31 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_31 max 100
bossbar set pk:lvl_31 value 31
bossbar set pk:lvl_31 color blue
bossbar set pk:lvl_31 style notched_10
bossbar add pk:lvl_32 [{text:"LEVEL ",color:"white",bold:true},{text:"32 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_32 max 100
bossbar set pk:lvl_32 value 32
bossbar set pk:lvl_32 color blue
bossbar set pk:lvl_32 style notched_10
bossbar add pk:lvl_33 [{text:"LEVEL ",color:"white",bold:true},{text:"33 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_33 max 100
bossbar set pk:lvl_33 value 33
bossbar set pk:lvl_33 color blue
bossbar set pk:lvl_33 style notched_10
bossbar add pk:lvl_34 [{text:"LEVEL ",color:"white",bold:true},{text:"34 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_34 max 100
bossbar set pk:lvl_34 value 34
bossbar set pk:lvl_34 color blue
bossbar set pk:lvl_34 style notched_10
bossbar add pk:lvl_35 [{text:"LEVEL ",color:"white",bold:true},{text:"35 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_35 max 100
bossbar set pk:lvl_35 value 35
bossbar set pk:lvl_35 color blue
bossbar set pk:lvl_35 style notched_10
bossbar add pk:lvl_36 [{text:"LEVEL ",color:"white",bold:true},{text:"36 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_36 max 100
bossbar set pk:lvl_36 value 36
bossbar set pk:lvl_36 color blue
bossbar set pk:lvl_36 style notched_10
bossbar add pk:lvl_37 [{text:"LEVEL ",color:"white",bold:true},{text:"37 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_37 max 100
bossbar set pk:lvl_37 value 37
bossbar set pk:lvl_37 color blue
bossbar set pk:lvl_37 style notched_10
bossbar add pk:lvl_38 [{text:"LEVEL ",color:"white",bold:true},{text:"38 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_38 max 100
bossbar set pk:lvl_38 value 38
bossbar set pk:lvl_38 color blue
bossbar set pk:lvl_38 style notched_10
bossbar add pk:lvl_39 [{text:"LEVEL ",color:"white",bold:true},{text:"39 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_39 max 100
bossbar set pk:lvl_39 value 39
bossbar set pk:lvl_39 color blue
bossbar set pk:lvl_39 style notched_10
bossbar add pk:lvl_40 [{text:"LEVEL ",color:"white",bold:true},{text:"40 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_40 max 100
bossbar set pk:lvl_40 value 40
bossbar set pk:lvl_40 color blue
bossbar set pk:lvl_40 style notched_10
bossbar add pk:lvl_41 [{text:"LEVEL ",color:"white",bold:true},{text:"41 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_41 max 100
bossbar set pk:lvl_41 value 41
bossbar set pk:lvl_41 color blue
bossbar set pk:lvl_41 style notched_10
bossbar add pk:lvl_42 [{text:"LEVEL ",color:"white",bold:true},{text:"42 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_42 max 100
bossbar set pk:lvl_42 value 42
bossbar set pk:lvl_42 color blue
bossbar set pk:lvl_42 style notched_10
bossbar add pk:lvl_43 [{text:"LEVEL ",color:"white",bold:true},{text:"43 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_43 max 100
bossbar set pk:lvl_43 value 43
bossbar set pk:lvl_43 color blue
bossbar set pk:lvl_43 style notched_10
bossbar add pk:lvl_44 [{text:"LEVEL ",color:"white",bold:true},{text:"44 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_44 max 100
bossbar set pk:lvl_44 value 44
bossbar set pk:lvl_44 color blue
bossbar set pk:lvl_44 style notched_10
bossbar add pk:lvl_45 [{text:"LEVEL ",color:"white",bold:true},{text:"45 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_45 max 100
bossbar set pk:lvl_45 value 45
bossbar set pk:lvl_45 color blue
bossbar set pk:lvl_45 style notched_10
bossbar add pk:lvl_46 [{text:"LEVEL ",color:"white",bold:true},{text:"46 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_46 max 100
bossbar set pk:lvl_46 value 46
bossbar set pk:lvl_46 color blue
bossbar set pk:lvl_46 style notched_10
bossbar add pk:lvl_47 [{text:"LEVEL ",color:"white",bold:true},{text:"47 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_47 max 100
bossbar set pk:lvl_47 value 47
bossbar set pk:lvl_47 color blue
bossbar set pk:lvl_47 style notched_10
bossbar add pk:lvl_48 [{text:"LEVEL ",color:"white",bold:true},{text:"48 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_48 max 100
bossbar set pk:lvl_48 value 48
bossbar set pk:lvl_48 color blue
bossbar set pk:lvl_48 style notched_10
bossbar add pk:lvl_49 [{text:"LEVEL ",color:"white",bold:true},{text:"49 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_49 max 100
bossbar set pk:lvl_49 value 49
bossbar set pk:lvl_49 color blue
bossbar set pk:lvl_49 style notched_10
bossbar add pk:lvl_50 [{text:"LEVEL ",color:"white",bold:true},{text:"50 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_50 max 100
bossbar set pk:lvl_50 value 50
bossbar set pk:lvl_50 color blue
bossbar set pk:lvl_50 style notched_10
bossbar add pk:lvl_51 [{text:"LEVEL ",color:"white",bold:true},{text:"51 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_51 max 100
bossbar set pk:lvl_51 value 51
bossbar set pk:lvl_51 color blue
bossbar set pk:lvl_51 style notched_10
bossbar add pk:lvl_52 [{text:"LEVEL ",color:"white",bold:true},{text:"52 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_52 max 100
bossbar set pk:lvl_52 value 52
bossbar set pk:lvl_52 color blue
bossbar set pk:lvl_52 style notched_10
bossbar add pk:lvl_53 [{text:"LEVEL ",color:"white",bold:true},{text:"53 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_53 max 100
bossbar set pk:lvl_53 value 53
bossbar set pk:lvl_53 color blue
bossbar set pk:lvl_53 style notched_10
bossbar add pk:lvl_54 [{text:"LEVEL ",color:"white",bold:true},{text:"54 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_54 max 100
bossbar set pk:lvl_54 value 54
bossbar set pk:lvl_54 color blue
bossbar set pk:lvl_54 style notched_10
bossbar add pk:lvl_55 [{text:"LEVEL ",color:"white",bold:true},{text:"55 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_55 max 100
bossbar set pk:lvl_55 value 55
bossbar set pk:lvl_55 color blue
bossbar set pk:lvl_55 style notched_10
bossbar add pk:lvl_56 [{text:"LEVEL ",color:"white",bold:true},{text:"56 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_56 max 100
bossbar set pk:lvl_56 value 56
bossbar set pk:lvl_56 color blue
bossbar set pk:lvl_56 style notched_10
bossbar add pk:lvl_57 [{text:"LEVEL ",color:"white",bold:true},{text:"57 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_57 max 100
bossbar set pk:lvl_57 value 57
bossbar set pk:lvl_57 color blue
bossbar set pk:lvl_57 style notched_10
bossbar add pk:lvl_58 [{text:"LEVEL ",color:"white",bold:true},{text:"58 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_58 max 100
bossbar set pk:lvl_58 value 58
bossbar set pk:lvl_58 color blue
bossbar set pk:lvl_58 style notched_10
bossbar add pk:lvl_59 [{text:"LEVEL ",color:"white",bold:true},{text:"59 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_59 max 100
bossbar set pk:lvl_59 value 59
bossbar set pk:lvl_59 color blue
bossbar set pk:lvl_59 style notched_10
bossbar add pk:lvl_60 [{text:"LEVEL ",color:"white",bold:true},{text:"60 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_60 max 100
bossbar set pk:lvl_60 value 60
bossbar set pk:lvl_60 color blue
bossbar set pk:lvl_60 style notched_10
bossbar add pk:lvl_61 [{text:"LEVEL ",color:"white",bold:true},{text:"61 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_61 max 100
bossbar set pk:lvl_61 value 61
bossbar set pk:lvl_61 color blue
bossbar set pk:lvl_61 style notched_10
bossbar add pk:lvl_62 [{text:"LEVEL ",color:"white",bold:true},{text:"62 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_62 max 100
bossbar set pk:lvl_62 value 62
bossbar set pk:lvl_62 color blue
bossbar set pk:lvl_62 style notched_10
bossbar add pk:lvl_63 [{text:"LEVEL ",color:"white",bold:true},{text:"63 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_63 max 100
bossbar set pk:lvl_63 value 63
bossbar set pk:lvl_63 color blue
bossbar set pk:lvl_63 style notched_10
bossbar add pk:lvl_64 [{text:"LEVEL ",color:"white",bold:true},{text:"64 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_64 max 100
bossbar set pk:lvl_64 value 64
bossbar set pk:lvl_64 color blue
bossbar set pk:lvl_64 style notched_10
bossbar add pk:lvl_65 [{text:"LEVEL ",color:"white",bold:true},{text:"65 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_65 max 100
bossbar set pk:lvl_65 value 65
bossbar set pk:lvl_65 color blue
bossbar set pk:lvl_65 style notched_10
bossbar add pk:lvl_66 [{text:"LEVEL ",color:"white",bold:true},{text:"66 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_66 max 100
bossbar set pk:lvl_66 value 66
bossbar set pk:lvl_66 color blue
bossbar set pk:lvl_66 style notched_10
bossbar add pk:lvl_67 [{text:"LEVEL ",color:"white",bold:true},{text:"67 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_67 max 100
bossbar set pk:lvl_67 value 67
bossbar set pk:lvl_67 color blue
bossbar set pk:lvl_67 style notched_10
bossbar add pk:lvl_68 [{text:"LEVEL ",color:"white",bold:true},{text:"68 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_68 max 100
bossbar set pk:lvl_68 value 68
bossbar set pk:lvl_68 color blue
bossbar set pk:lvl_68 style notched_10
bossbar add pk:lvl_69 [{text:"LEVEL ",color:"white",bold:true},{text:"69 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_69 max 100
bossbar set pk:lvl_69 value 69
bossbar set pk:lvl_69 color blue
bossbar set pk:lvl_69 style notched_10
bossbar add pk:lvl_70 [{text:"LEVEL ",color:"white",bold:true},{text:"70 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_70 max 100
bossbar set pk:lvl_70 value 70
bossbar set pk:lvl_70 color blue
bossbar set pk:lvl_70 style notched_10
bossbar add pk:lvl_71 [{text:"LEVEL ",color:"white",bold:true},{text:"71 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_71 max 100
bossbar set pk:lvl_71 value 71
bossbar set pk:lvl_71 color blue
bossbar set pk:lvl_71 style notched_10
bossbar add pk:lvl_72 [{text:"LEVEL ",color:"white",bold:true},{text:"72 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_72 max 100
bossbar set pk:lvl_72 value 72
bossbar set pk:lvl_72 color blue
bossbar set pk:lvl_72 style notched_10
bossbar add pk:lvl_73 [{text:"LEVEL ",color:"white",bold:true},{text:"73 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_73 max 100
bossbar set pk:lvl_73 value 73
bossbar set pk:lvl_73 color blue
bossbar set pk:lvl_73 style notched_10
bossbar add pk:lvl_74 [{text:"LEVEL ",color:"white",bold:true},{text:"74 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_74 max 100
bossbar set pk:lvl_74 value 74
bossbar set pk:lvl_74 color blue
bossbar set pk:lvl_74 style notched_10
bossbar add pk:lvl_75 [{text:"LEVEL ",color:"white",bold:true},{text:"75 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_75 max 100
bossbar set pk:lvl_75 value 75
bossbar set pk:lvl_75 color blue
bossbar set pk:lvl_75 style notched_10
bossbar add pk:lvl_76 [{text:"LEVEL ",color:"white",bold:true},{text:"76 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_76 max 100
bossbar set pk:lvl_76 value 76
bossbar set pk:lvl_76 color blue
bossbar set pk:lvl_76 style notched_10
bossbar add pk:lvl_77 [{text:"LEVEL ",color:"white",bold:true},{text:"77 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_77 max 100
bossbar set pk:lvl_77 value 77
bossbar set pk:lvl_77 color blue
bossbar set pk:lvl_77 style notched_10
bossbar add pk:lvl_78 [{text:"LEVEL ",color:"white",bold:true},{text:"78 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_78 max 100
bossbar set pk:lvl_78 value 78
bossbar set pk:lvl_78 color blue
bossbar set pk:lvl_78 style notched_10
bossbar add pk:lvl_79 [{text:"LEVEL ",color:"white",bold:true},{text:"79 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_79 max 100
bossbar set pk:lvl_79 value 79
bossbar set pk:lvl_79 color blue
bossbar set pk:lvl_79 style notched_10
bossbar add pk:lvl_80 [{text:"LEVEL ",color:"white",bold:true},{text:"80 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_80 max 100
bossbar set pk:lvl_80 value 80
bossbar set pk:lvl_80 color blue
bossbar set pk:lvl_80 style notched_10
bossbar add pk:lvl_81 [{text:"LEVEL ",color:"white",bold:true},{text:"81 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_81 max 100
bossbar set pk:lvl_81 value 81
bossbar set pk:lvl_81 color blue
bossbar set pk:lvl_81 style notched_10
bossbar add pk:lvl_82 [{text:"LEVEL ",color:"white",bold:true},{text:"82 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_82 max 100
bossbar set pk:lvl_82 value 82
bossbar set pk:lvl_82 color blue
bossbar set pk:lvl_82 style notched_10
bossbar add pk:lvl_83 [{text:"LEVEL ",color:"white",bold:true},{text:"83 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_83 max 100
bossbar set pk:lvl_83 value 83
bossbar set pk:lvl_83 color blue
bossbar set pk:lvl_83 style notched_10
bossbar add pk:lvl_84 [{text:"LEVEL ",color:"white",bold:true},{text:"84 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_84 max 100
bossbar set pk:lvl_84 value 84
bossbar set pk:lvl_84 color blue
bossbar set pk:lvl_84 style notched_10
bossbar add pk:lvl_85 [{text:"LEVEL ",color:"white",bold:true},{text:"85 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_85 max 100
bossbar set pk:lvl_85 value 85
bossbar set pk:lvl_85 color blue
bossbar set pk:lvl_85 style notched_10
bossbar add pk:lvl_86 [{text:"LEVEL ",color:"white",bold:true},{text:"86 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_86 max 100
bossbar set pk:lvl_86 value 86
bossbar set pk:lvl_86 color blue
bossbar set pk:lvl_86 style notched_10
bossbar add pk:lvl_87 [{text:"LEVEL ",color:"white",bold:true},{text:"87 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_87 max 100
bossbar set pk:lvl_87 value 87
bossbar set pk:lvl_87 color blue
bossbar set pk:lvl_87 style notched_10
bossbar add pk:lvl_88 [{text:"LEVEL ",color:"white",bold:true},{text:"88 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_88 max 100
bossbar set pk:lvl_88 value 88
bossbar set pk:lvl_88 color blue
bossbar set pk:lvl_88 style notched_10
bossbar add pk:lvl_89 [{text:"LEVEL ",color:"white",bold:true},{text:"89 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_89 max 100
bossbar set pk:lvl_89 value 89
bossbar set pk:lvl_89 color blue
bossbar set pk:lvl_89 style notched_10
bossbar add pk:lvl_90 [{text:"LEVEL ",color:"white",bold:true},{text:"90 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_90 max 100
bossbar set pk:lvl_90 value 90
bossbar set pk:lvl_90 color blue
bossbar set pk:lvl_90 style notched_10
bossbar add pk:lvl_91 [{text:"LEVEL ",color:"white",bold:true},{text:"91 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_91 max 100
bossbar set pk:lvl_91 value 91
bossbar set pk:lvl_91 color blue
bossbar set pk:lvl_91 style notched_10
bossbar add pk:lvl_92 [{text:"LEVEL ",color:"white",bold:true},{text:"92 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_92 max 100
bossbar set pk:lvl_92 value 92
bossbar set pk:lvl_92 color blue
bossbar set pk:lvl_92 style notched_10
bossbar add pk:lvl_93 [{text:"LEVEL ",color:"white",bold:true},{text:"93 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_93 max 100
bossbar set pk:lvl_93 value 93
bossbar set pk:lvl_93 color blue
bossbar set pk:lvl_93 style notched_10
bossbar add pk:lvl_94 [{text:"LEVEL ",color:"white",bold:true},{text:"94 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_94 max 100
bossbar set pk:lvl_94 value 94
bossbar set pk:lvl_94 color blue
bossbar set pk:lvl_94 style notched_10
bossbar add pk:lvl_95 [{text:"LEVEL ",color:"white",bold:true},{text:"95 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_95 max 100
bossbar set pk:lvl_95 value 95
bossbar set pk:lvl_95 color blue
bossbar set pk:lvl_95 style notched_10
bossbar add pk:lvl_96 [{text:"LEVEL ",color:"white",bold:true},{text:"96 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_96 max 100
bossbar set pk:lvl_96 value 96
bossbar set pk:lvl_96 color blue
bossbar set pk:lvl_96 style notched_10
bossbar add pk:lvl_97 [{text:"LEVEL ",color:"white",bold:true},{text:"97 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_97 max 100
bossbar set pk:lvl_97 value 97
bossbar set pk:lvl_97 color blue
bossbar set pk:lvl_97 style notched_10
bossbar add pk:lvl_98 [{text:"LEVEL ",color:"white",bold:true},{text:"98 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_98 max 100
bossbar set pk:lvl_98 value 98
bossbar set pk:lvl_98 color blue
bossbar set pk:lvl_98 style notched_10
bossbar add pk:lvl_99 [{text:"LEVEL ",color:"white",bold:true},{text:"99 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_99 max 100
bossbar set pk:lvl_99 value 99
bossbar set pk:lvl_99 color blue
bossbar set pk:lvl_99 style notched_10
bossbar add pk:lvl_100 [{text:"LEVEL ",color:"white",bold:true},{text:"100 / 100",color:"aqua",bold:true}]
bossbar set pk:lvl_100 max 100
bossbar set pk:lvl_100 value 100
bossbar set pk:lvl_100 color blue
bossbar set pk:lvl_100 style notched_10
