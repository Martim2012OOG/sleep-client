title @s subtitle {text:"Last checkpoint reached!",color:"white"}
title @s title {text:"Level 100",color:"gold",bold:true}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
