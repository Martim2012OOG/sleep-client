execute store result storage pk:bar old int 1 run scoreboard players get @s pk_shown
execute store result storage pk:bar new int 1 run scoreboard players get @s pk_level
scoreboard players operation @s pk_shown = @s pk_level
function pk:bar_apply with storage pk:bar
