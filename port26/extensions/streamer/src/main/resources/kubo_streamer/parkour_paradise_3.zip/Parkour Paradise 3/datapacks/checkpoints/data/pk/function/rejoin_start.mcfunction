scoreboard players reset @s pk_left
scoreboard players set @s pk_rejoin 25
